/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patelnlab4;

/**
 *
 * @author s541667
 */
import java.util.*;
public class PatelNLab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Initialize variables        
        Scanner kbd = new Scanner(System.in);        
        String fName, lName, fullName;        
        int birthYear, age;        
        double gpa1, gpa2, gpa3, avgGPA;        
        final int CURRENT_YEAR = 2018;        

        //Collect info from user        
        System.out.print("What is your first name? ");        
        fName = kbd.next();        
        System.out.print("What is your last name? ");        
        lName = kbd.next();        
        System.out.print("What year were you born? ");        
        birthYear = kbd.nextInt();        
        System.out.print("Enter first GPA: ");        
        gpa1 = kbd.nextDouble();        
        System.out.print("Enter second GPA: ");        
        gpa2 = kbd.nextDouble();        
        System.out.print("Enter third GPA: ");        
        gpa3 = kbd.nextDouble();
        
        //Call methods        
        fullName = fullName(fName, lName);       
        age = ageCalc(birthYear, CURRENT_YEAR);        
        avgGPA = gpaCalc(gpa1, gpa2, gpa3);       
        printInfo(fullName, age, avgGPA);
        
    }
    //Call methods 
    
    public static String fullName(String firstName, String lastName){
        String fullName = lastName + ", " + firstName;
        return fullName;
    }
    
    public static int ageCalc(int birthYear,int currentYear){
        int age = currentYear - birthYear;
        return age;
    }
    
    public static double gpaCalc(double gpa1, double gpa2, double gpa3) {
        double avgGPA = (gpa1 + gpa2 + gpa3)/3.0;
        return avgGPA;
    }
    
    public static void printInfo(String fullName, int age , double avgGPA){
        System.out.println("");
        System.out.println("Name: " + fullName);
        System.out.println("Age: " + age + " years");
        System.out.printf("Cumulative GPA: %.2f\n" , avgGPA);
        
    }
}
